
var app = angular.module('pokemonApp', []);

app.controller('pokemonCtrl', function($scope, $http, $filter) {

    const restUrl = "https://pokeapi.co/api/v2/pokemon/?limit=151";

    $scope.pokemons = [];
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.searchText = '';

    $http.get(restUrl).then( successCallback , errorCallback);

    function successCallback(response){
         //success code
         $scope.pokemons = response.data.results;

         const stringToTrim = "https://pokeapi.co/api/v2/pokemon/";
         const imagePath = 'images/';
         const imageExt = '.png';

         for(var i = 0; i < $scope.pokemons.length; i++) {
            var imageNumberInUrl = $scope.pokemons[i].url;
            $scope.pokemons[i].url = imageNumberInUrl.slice(stringToTrim.length, imageNumberInUrl.lastIndexOf("/"));
            $scope.pokemons[i].imageUrl = imagePath +  $scope.pokemons[i].url + imageExt;
         }
    }
    function errorCallback(error){
		//error code
        console.log("Couldn't get Pokemon. Communication error..");
        console.log("Error Status: "+error.status);
        console.log("Error Text: "+error.statusText);
    }

    $scope.getData = function() {
        return $filter('filter')($scope.pokemons, $scope.searchText)
    };

    $scope.numberOfPages=function(){
        return Math.ceil($scope.getData().length/$scope.pageSize);
    };

});

app.filter('showResultFrom', function() {
        //start index of the pokemon..0,20,40,60...
        //
        return function(pokemons, index) {
        return pokemons.slice(index);
    }
});